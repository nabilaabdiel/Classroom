package com.abdiel.classroom.base.viewModel

import com.crocodic.core.base.viewmodel.CoreViewModel

open class BaseViewModel: CoreViewModel() {
    override fun apiLogout() {
    }

    override fun apiRenewToken(){

    }
}